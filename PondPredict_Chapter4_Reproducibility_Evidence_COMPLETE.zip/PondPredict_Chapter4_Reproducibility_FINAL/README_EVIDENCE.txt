PondPredict — Chapter 4 ML Reproducibility Evidence (COLLECTED)

This package gathers the submitted original datasets, code, saved models, scalers,
CSV outputs, figures, and software dependency inventory. Python version: 3.14.0.

Verified checks:
- Figures 12–18 are EXACT pixel matches to the saved plotting outputs in
  the supplied final-model notebooks. See FIGURE_OUTPUT_AUTHENTICATION.csv.
- Plotted histories originate from the final-model training cells, according
  to notebook variable linkage. A saved model does not contain its training history.
- CV result files and graphs use the corrected October 27 rerun, not the old fold values.
- Final test checkpoints and paired exported predictions were checked earlier against
  38 Philippine held-out targets; model scores and final CSVs are reconciled.
- Both original Indonesian and Philippine source datasets included.
- Python packages and versions included; see environment/requirements_final.txt.
- Fixed random seed 42 documented in code; not evidence of independent multi-seed stability.

Traceability:
- FIGURE_TRACEABILITY.csv and FIGURE_OUTPUT_AUTHENTICATION.csv for Figures 12–26.
- TABLE_TRACEABILITY.csv for Tables 7–21.
- SHA256SUMS.txt for checking file integrity.

Boundaries of evidence:
- This package does NOT demonstrate independent, from-scratch clean-environment retraining.
- Training histories are saved in notebook outputs, not embedded in .keras model archives.
- System-level package freeze records packages installed at collection, which may differ
  from exactly those installed on the original date each experiment was performed.
- The notebook code demonstrates fold separation and train-only fit; actual execution
  outputs substantiate reported metrics, but cannot rule out every undiscovered process error.
- Single-seed findings should not be described as multi-seed stability evidence.

For independent replication, use a COPY of the project. Running training in the live
project can overwrite saved .keras checkpoints and CSVs. Follow 01→02→03→04→05→06
with input paths and execution conditions checked.
